<?php
include("global/sessiones.php");
echo "Hola soy producto del modulo";

?>