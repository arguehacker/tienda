<?php

if (isset($_POST['btnLogin'])){
	include("global/db.php");

	$txtEmail=$_POST['txtEmail'];
	$txtPassword=$_POST['txtPassword'];
	$sentenciaSQL=$pdo->prepare("SELECT * FROM administrador WHERE Correo=:correo AND Password=:password");
	$sentenciaSQL->bindParam("correo",$txtEmail,PDO::PARAM_STR);
	$sentenciaSQL->bindParam("password",$txtPassword,PDO::PARAM_STR);
	$sentenciaSQL->execute();

	$registro = $sentenciaSQL->fetch(PDO::FETCH_ASSOC);

	//print_r($registro);

	$numeroRegistro = $sentenciaSQL->rowCount();

	if ($numeroRegistro>=1){
		//INICIO MI SESSION DE ADMISTRADOR
		session_start();
		$_SESSION['administrador']=$registro;
		header('location:VistaPanel.php');
		echo "Bienvenido";
	}else{
		echo "No se ha encontrado registros";
	}
}
?>