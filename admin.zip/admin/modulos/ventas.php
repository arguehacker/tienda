<?php
include("global/sessiones.php");
echo "Hola soy ventas del modulo";

?>