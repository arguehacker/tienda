<?php
include("global/sessiones.php");

#CONEXION A BASE DE DATOS store
$conexion = mysqli_connect("localhost","root","","store") or die ("error al conectar a la base de datos store".mysql_error());

?>