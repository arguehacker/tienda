<?php
include("global/sessiones.php");
include("global/db.php");

//TOTAL DE VENTAS Y INGRESOS
$sentenciaSQL=$pdo->prepare("SELECT count(*) totalVentas,SUM(Total) as IngresoTotalVentas FROM `ventas` WHERE PaypalDatos<>''");
$sentenciaSQL->execute();
$registro = $sentenciaSQL->fetch(PDO::FETCH_ASSOC);

$totalVentas=$registro['totalVentas'];
$IngresoTotalesVentas=$registro['IngresoTotalVentas'];

//SENTENCIA DE PENDIENTES

$sentenciaSQL=$pdo->prepare("SELECT count(*) totalVentas FROM `ventas` WHERE PaypalDatos=''");
$sentenciaSQL->execute();
$registro = $sentenciaSQL->fetch(PDO::FETCH_ASSOC);

$totalVentasPendientes=$registro['totalVentas'];

//SIRVE PARA MOSTRAR EN VISTA PANEL TODAS LAS VENTAS
$sentencia = $pdo->prepare("SELECT * FROM `ventas` WHERE 1");
$sentencia->execute();
$listaProd = $sentencia->fetchAll(PDO::FETCH_ASSOC);
//FIN MOSTRAS VENTA
?>