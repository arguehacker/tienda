
<?php
include("global/sessiones.php");
include("global/db.php");
?>
<?php
echo "";


?>

<?php
//incluimos la coneccion a la base de datos//

// receccion de las variables enviadas por el metodo post del formulaario para regitrar los productos
$ID=(isset($_POST['ID']))?$_POST['ID']:"";
$nombresAdmin=(isset($_POST['nombres']))?$_POST['nombres']:"";
$apellidosAdmin=(isset($_POST['apellidos']))?$_POST['apellidos']:"";
$correoAdmin=(isset($_POST['correo']))?$_POST['correo']:"";
$passwordAdmin=(isset($_POST['password']))?$_POST['password']:""; //Encriptacion de md5
$txtFoto=(isset($_FILES['txtFoto']["name"]))?$_FILES['txtFoto']:"";

$accion=(isset($_POST['accion']))?$_POST['accion']:"";

//hacemos un case par identificar cuando precione el botton el usuario

switch($accion){

  case "btnmodificar":
  //CONEXION A LA BASEDE DATOS PARA MODIFICAR PRODUCTOS


       
   $sentencia=$pdo->prepare("UPDATE `administrador` SET `Nombres` =:Nombres, `Apellidos` =:Apellidos, `Correo` =:Correo, `Password` =:Password WHERE `ID`=:ID;");

      $sentencia->bindParam(':Nombres', $nombresAdmin);
      $sentencia->bindParam(':Apellidos',$apellidosAdmin);
      $sentencia->bindParam(':Correo',$correoAdmin );
      $sentencia->bindParam(':Password',$passwordAdmin);
      $sentencia->bindParam('ID',$ID );
      $sentencia->execute();

    //actualizar fotografia

     $Fecha= new DateTime();
    $nombreArchivo = ($txtFoto >=0)?$Fecha->getTimestamp()."_".$_FILES["txtFoto"]["name"]:"foto.jpg";

    $tmpFoto = $_FILES["txtFoto"]["tmp_name"];

    if($tmpFoto!=""){// la que daba error el signo de almiracion lo cambien por el que tiene//
      move_uploaded_file($tmpFoto,"../assets/fotosAdmin/".$nombreArchivo);

  $sentencia=$pdo->prepare("UPDATE administrador  SET 
  Foto=:Imagen WHERE ID=:id");
     $sentencia->bindParam(':Imagen',$nombreArchivo);
    
    $sentencia->bindParam(':id',$ID);
    $sentencia->execute();
  }
    break;

  }