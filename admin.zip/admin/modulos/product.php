<?php
include("global/sessiones.php");
//echo "Hola soy producto del modulo";
include("global/db.php");
?>

<?php
//incluimos la coneccion a la base de datos//

// receccion de las variables enviadas por el metodo post del formulaario para regitrar los productos
$codigop=(isset($_POST['codigop']))?$_POST['codigop']:"";
$nombrep=(isset($_POST['nombrep']))?$_POST['nombrep']:"";
$preciop=(isset($_POST['preciop']))?$_POST['preciop']:"";
$modelop=(isset($_POST['modelop']))?$_POST['modelop']:"";
$marcap=(isset($_POST['marcap']))?$_POST['marcap']:"";
$txtFoto=(isset($_FILES['txtFoto']["name"]))?$_FILES['txtFoto']:"";

$accion=(isset($_POST['accion']))?$_POST['accion']:"";

//hacemos un case par identificar cuando precione el botton el usuario

switch($accion){
  case "btnagregar":
  //sentencia para ingresar productos mediante el case

    $sentencia=$pdo->prepare("INSERT INTO  productos (CodigoProd, NombreProd, Precio, Modelo, Marca, Imagen) 
    VALUES(:CodigoProd, :NombreProd, :Precio, :Modelo, :Marca, :Imagen) ");

    $sentencia->bindParam(':CodigoProd',$codigop );
    $sentencia->bindParam(':NombreProd', $nombrep);
    $sentencia->bindParam(':Precio',$preciop);
    $sentencia->bindParam(':Modelo',$modelop);
    $sentencia->bindParam(':Marca',$marcap);

    //esto es para ingresar la fotografia i copiarlo ar la carpeta selecionada mediante la fecha //
    $Fecha= new DateTime();
    $nombreArchivo = ($txtFoto!="")?$Fecha->getTimestamp()."_".$_FILES["txtFoto"]["name"]:"producto.jpg";

    $tmpFoto = $_FILES["txtFoto"]["tmp_name"];

    if($tmpFoto!=""){
      move_uploaded_file($tmpFoto,"../assets/img-products/".$nombreArchivo);
    }


    $sentencia->bindParam(':Imagen',$nombreArchivo);
    $sentencia->execute();
    header("location:VistaProduct.php");

    break;


  case "btnmodificar":
  //CONEXION A LA BASEDE DATOS PARA MODIFICAR PRODUCTOS 
       
   $sentencia=$pdo->prepare("UPDATE productos  SET 
    NombreProd=:NombreProd,
    Precio=:Precio,
    Modelo=:Modelo,
    Marca=:Marca
  
    WHERE
     CodigoProd=:id"); 
      $sentencia->bindParam(':NombreProd', $nombrep);
      $sentencia->bindParam(':Precio',$preciop);
      $sentencia->bindParam(':Modelo',$modelop );
      $sentencia->bindParam(':Marca',$marcap);
      $sentencia->bindParam('id',$codigop );
      $sentencia->execute();

    //actualizar fotografia

     $Fecha= new DateTime();
    $nombreArchivo = ($txtFoto >=0)?$Fecha->getTimestamp()."_".$_FILES["txtFoto"]["name"]:"productoo.jpg";

    $tmpFoto = $_FILES["txtFoto"]["tmp_name"];

    if($tmpFoto!=""){// la que daba error el signo de almiracion lo cambien por el que tiene//
      move_uploaded_file($tmpFoto,"../assets/img-products/".$nombreArchivo);

  $sentencia=$pdo->prepare("UPDATE productos  SET 
  Imagen=:Imagen WHERE CodigoProd=:id");
     $sentencia->bindParam(':Imagen',$nombreArchivo);
    
    $sentencia->bindParam(':id',$codigop);
    $sentencia->execute();
  } 
    break;

  case "btneliminar":

  //para borrar la foto de la carpeta donde se guardan en prueva falta //
  $sentencia=$pdo->prepare("SELECT Imagen FROM `productos` WHERE CodigoProd=:id");
  $sentencia->bindParam(':id',$codigop);
  $sentencia->execute();
  $fila= $sentencia->fetch(PDO::FETCH_LAZY);
  //print_r($fila);//solo para provar//

  if(isset($fila["Imagen"])){
     if (file_exists("../assets/img-products/".$fila["Imagen"])) {
       unlink("../assets/img-products/".$fila["Imagen"]);
     }
    } 
    //sentencia sql para eliminar productos
           
    $sentencia=$pdo->prepare("DELETE FROM `productos` WHERE CodigoProd=:id"); 
    $sentencia->bindParam(':id',$codigop );
    $sentencia->execute();
    header("location:VistaProduct.php");
  break;

  case "btncancelar":
    header("location:VistaProduct.php");

  break;
}

//Sentencia para mostrar información de la tabla productos
$sentencia = $pdo->prepare("SELECT * FROM `productos` WHERE 1");
$sentencia->execute();
$listaProd = $sentencia->fetchAll(PDO::FETCH_ASSOC);          
?>
