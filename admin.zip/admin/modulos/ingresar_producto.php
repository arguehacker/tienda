<?php
// receccion de las variables enviadas por el metodo post del formulaario para regitrar los productos


$codigop=(isset($_POST['codigop']))?$_POST['codigop']:"";
$nombrep=(isset($_POST['nombrep']))?$_POST['nombrep']:"";
$preciop=(isset($_POST['preciop']))?$_POST['preciop']:"";
$modelop=(isset($_POST['modelop']))?$_POST['modelop']:"";
$marcap=(isset($_POST['marcap']))?$_POST['marcap']:"";
$imagenp=(isset($_FILES['imagenp']["name"]))?$_FILES['imagenp']:"";

$accion=(isset($_POST['accion']))?$_POST['accion']:"";



//incluimos la coneccion a la base de datos//

include "global/config.php";
include "global/db.php";


//hacemos un case par identificar cuando precione el botton el usuario



switch($accion){
  case "btnagregar":
  //sentencia para ingresar productos mediante el case

    $sentencia=$pdo->prepare("INSERT INTO  productos (CodigoProd, NombreProd, Precio, Modelo, Marca, Imagen) 
    VALUES(:CodigoProd, :NombreProd, :Precio, :Modelo, :Marca, :Imagen) ");

    $sentencia->bindParam(':CodigoProd',$codigop );
    $sentencia->bindParam(':NombreProd', $nombrep);
    $sentencia->bindParam(':Precio',$preciop);
    $sentencia->bindParam(':Modelo',$modelop);
    $sentencia->bindParam(':Marca',$marcap);

    //esto es para ingresar la fotografia i copiarlo ar la carpeta selecionada mediante la fecha //
    $Fecha= new DateTime();
    $nombreArchivo = ($imagenp>=0)?$Fecha->getTimestamp()."_".$_FILES["imagenp"]["name"]:"ty.jpg";

    $tmpFoto = $_FILES["imagenp"]["tmp_name"];

    if($tmpFoto    <=0){
      move_uploaded_file($tmpFoto,"./assets/img-products/".$nombreArchivo);
    }


    $sentencia->bindParam(':Imagen',$nombreArchivo
  );
    $sentencia->execute();

    break;


  case "btnmodificar":
  //CONEXION A LA BASEDE DATOS PARA MODIFICAR PRODUCTOS 
       
$sentencia=$pdo->prepare("UPDATE productos  SET 
  NombreProd=:NombreProd,
  Precio=:Precio,
  Modelo=:Modelo,
  Marca=:Marca
  
  WHERE
   CodigoProd=:id"); 
    $sentencia->bindParam(':NombreProd', $nombrep);
    $sentencia->bindParam(':Precio',$preciop);
    $sentencia->bindParam(':Modelo',$modelop );
    $sentencia->bindParam(':Marca',$marcap);
    $sentencia->bindParam('id',$codigop );
    $sentencia->execute();

    //actualizar fotografia

     $Fecha= new DateTime();
    $nombreArchivo = ($imagenp >=0)?$Fecha->getTimestamp()."_".$_FILES["imagenp"]["name"]:"ty.jpg";

    $tmpFoto = $_FILES["imagenp"]["tmp_name"];

    if($tmpFoto <=0){// la que daba error el signo de almiracion lo cambien por el que tiene//
      move_uploaded_file($tmpFoto,"./assets/img-products/".$nombreArchivo);

  $sentencia=$pdo->prepare("UPDATE productos  SET 
  Imagen=:Imagen WHERE CodigoProd=:id");
     $sentencia->bindParam(':Imagen',$nombreArchivo);
    
    $sentencia->bindParam(':id',$codigop);
    $sentencia->execute();

  } 




    break;

  case "btneliminar":

//paraborrar la foto de la carpeta donde se guardan en prueva falta //
$sentencia=$pdo->prepare("SELECT Imagen FROM `productos` WHERE CodigoProd=:id");
$sentencia->bindParam(':id',$codigop);
$sentencia->execute();
$fila= $sentencia->fetch(PDO::FETCH_LAZY);
print_r($fila);//solo para provar//

if(isset($fila["Imagen"])){
   if (file_exists("./assets/img-products/".$fila["Imagen"])) {

     unlink("./assets/img-products/".$fila["Imagen"]);
   }

  } 
  //sentencia sql para eliminar productos
         
  $sentencia=$pdo->prepare("DELETE from  productos
  WHERE
   CodigoProd =:id"); 

    $sentencia->bindParam(':id',$codigop );
    $sentencia->execute();
header('Locatio:ingresar_producto.php');
    break;

case "btncancelar":


   break;
}
//Sentencia para mostrar información de la tabla productos
   
 $sentencia = $pdo->prepare("SELECT * FROM `productos` WHERE 1");
$sentencia->execute();
$listaProd = $sentencia->fetchAll(PDO::FETCH_ASSOC);
             
?>


<!-- Codigo html  formulario de la recesion de datos  que pone el administrador----------- -->

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link href="../../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all"><!---  mando a llamar esa enlace para darle estilo  a formulario prueva- -->
	<title>
pruevas
</title>
</head>
<body>

<div class="wrapper row3">
  <main class="hoc container clear"> 
  <div id="comments">
        <h2>ingresar prductos nuevos</h2>

        <form action="" method="post" enctype="multipart/form-data" > <!---  palabra reservada de html para ingresar fotos- -->

          <div class="one_third first">
            <label for="codigo">codigo</label>
            <input type="text" name="codigop" id="Nombres" placeholder="codigo" value="<?php echo $codigop;?>" size="22">
          </div>
           <br>



          <div class="one_third first">
            <label for="nombres">Nombre </label>
            <input type="text" name="nombrep" id="Nombres" placeholder="Nombre" value="<?php echo $nombrep;?>" size="22" required>
          </div>

          <div class="one_third">
            <label for="descripcion">Precio</label>
            <input type="text" name="preciop" id="precio" placeholder="Precio" value="<?php echo $preciop;?>" size="22" required>  
          </div>

           <div class="one_third">
            <label for="descripcion">Modelo</label>
            <input type="text" name="modelop" id="modelo" placeholder="Modelo" value="<?php echo $modelop;?>" size="22" required>  
          </div>
           <div class="one_third">
            <label for="descripcion">Marca</label>
            <input type="text" name="marcap" id="marca" placeholder="marca" value="<?php echo $marcap;?>" size="22" required>  
          </div>
           <div class="one_third">
            <label >Imagen</label><!---  se cambia el formulario por type file - -->
            <input type="file" accept="image/*" name="imagenp"  value="<?php echo $imagenp;?>" >  
          </div>
          <!---  botones tipo submit - -->
           
         <button class="btn" type="submit" name="accion" value="btnagregar"> Agregar 
            </button>

         <button class="btn" type="submit" name="accion" value="btnmodificar"> Modificar 
         </button>


          <button class="btn" type="submit" name="accion" value="btneliminar"> Eliminar 
          </button>


        <button class="btn" type="submit" name="accion" value="btncancelar"> Cancelar 
        </button>

        </form>



           
      <div class= "row">               
        <table>
        <thead><!---  mostrar los productos  al usuario  mediante un foreach la $listaProd es la variable que sacamos de la consulta a la base de datos- -->
          <tr>
             <th>Codigo</th>
             <th>Nombre</th>
             <th>Precio</th>
              <th>Modelo</th>
               <th>Marca</th>
                <th>Imagen</th>
             <th>Acciones</th>
           </tr>
        </thead>
         
        <?php foreach ($listaProd as $fila){?>
         <tr>
           <td> <?php echo $fila ['CodigoProd']; ?> </td>
           <td><?php echo $fila ['NombreProd']; ?> </td>
           <td><?php echo $fila ['Precio']; ?> </td>
           <td><?php echo $fila ['Modelo']; ?> </td>
           <td><?php echo $fila ['Marca']; ?> </td>
           <td> <img class ="img-thumbnail" width= "100px" src="../assets/img-products/<?php echo $fila ['Imagen']; ?>" /> </td>
          
            <td>   <!-- adentro del td hacemos un formulario oculto con la palabra  hidden para enviar las variables al otro formulario. las variables de los corchetes son los nombres a la base de datos -->

 
       <form action="" method="post">

       <input type="hidden" name="codigop" value="<?php echo $fila ['CodigoProd']; ?>">
 
      <input type="hidden" name="nombrep" value="<?php echo $fila ['NombreProd']; ?>"> 


      <input type="hidden" name="preciop" value="<?php echo $fila ['Precio']; ?>"> 


       <input type="hidden" name="modelop" value="<?php echo $fila ['Modelo']; ?>"> 

        <input type="hidden" name="marcap" value="<?php echo $fila ['Marca']; ?>"> 

       <input type="hidden" name="imagenp" value="<?php echo $fila ['Imagen']; ?>"> 


<!---  botones para eliminar y selecionar-->
       <input type="submit" value="Seleccionar"  name = "accion"> 

       <button class="btn" type="submit" name="accion" value="btneliminar"> Eliminar 
          </button>

     

    </form>
  
  <td>  
   </tr>
     <?php   }?><!---  se ciera la llave del forech -->
    </table>


    </div>  
    </div>  
   
    </main>
    </div> 
    
</body>
</html>