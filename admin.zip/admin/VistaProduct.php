<?php
include("modulos/product.php"); 
include("cabecera.php");
include("sidebar.php");
?>

  <!-- Left side column. contains the logo and sidebar -->


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      


      <!-- /.row -->
      <!---Formulario de producto-->

          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Administrar Productos</h3>
            </div>
            <!-- /.box-header -->

            <!-- form start -->
            <form role="form" action="" method="post" enctype="multipart/form-data">
              <div class="one_third first">
              <!--<label for="codigo">codigo</label>-->
                <input type="hidden" name="codigop" id="Nombres" placeholder="codigo" value="<?php echo $codigop;?>">
              </div>
              <div class="box-body">
                <div class="form-group">
                  <label for="exampleInputEmail1">Nombre de Producto</label>
                  <input type="text" name="nombrep" class="form-control" id="exampleInputEmail1" placeholder="Producto" value="<?php echo $nombrep;?>" required="">
                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1">Precio</label>
                  <input type="text" name="preciop" class="form-control" id="exampleInputEmail1" placeholder="$" value="<?php echo $preciop;?>" required="">
                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1">Modelo</label>
                  <input type="text" name="modelop" class="form-control" id="exampleInputEmail1" placeholder="Modelo" value="<?php echo $modelop;?>" required="">
                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1">Marca</label>
                  <input type="text" name="marcap" class="form-control" id="exampleInputEmail1" placeholder="Marca" value="<?php echo $marcap;?>" required="">
                </div>

                <div class="form-group">
                  <label for="exampleInputFile">Agregar imagen</label>
                  <input type="file" accept="image/*" name="txtFoto" id="exampleInputFile" value="<?php echo $imagenp;?>" required>
                </div>
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button class="btn btn-primary" type="submit" name="accion" value="btnagregar">Agregar</button>
              </div>
              <div class="box-footer">
                <button class="btn btn-primary" type="submit" name="accion" value="btnmodificar">Actualizar</button>
              </div>
            </form>
          </div>
          <!-- form end -->
          <!--Mostrar Productos-->
          <div class="col-xs-12">
            <div class="box">
              <div class="box-header">
                <h3 class="box-title">Productos disponibles en tienda</h3>

                <div class="box-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                    <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">

                    <div class="input-group-btn">
                      <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                    </div>
                  </div>
                </div>
              </div>
            <!-- /.box-header -->

            <div class="box-body table-responsive no-padding">
              <table class="table table-hover">
                <tbody><tr>
                  <th>ID</th>
                  <th>Nombre</th>
                  <th>Precio</th>
                  <th>Modelo</th>
                  <th>Marca</th>
                  <th>Imagen</th>
                  <th class="text-center">Acción</th>
                </tr>
                <?php foreach ($listaProd as $fila){?>
                <tr>
                  <td><?php echo $fila ['CodigoProd']; ?></td>
                  <td><?php echo $fila ['NombreProd']; ?></td>
                  <td>$<?php echo number_format($fila ['Precio'],2); ?></td>
                  <td><?php echo $fila ['Modelo']; ?></td>
                  <td><?php echo $fila ['Marca']; ?></td>
                  <td><img class ="img-thumbnail" width= "100px" src="../assets/img-products/<?php echo $fila ['Imagen']; ?>" /></td>
                  <td>
                    <form action="" method="post">
                      <input type="hidden" name="codigop" value="<?php echo $fila ['CodigoProd']; ?>">
                      <input type="hidden" name="nombrep" value="<?php echo $fila ['NombreProd']; ?>"> 
                      <input type="hidden" name="preciop" value="<?php echo $fila ['Precio']; ?>">
                      <input type="hidden" name="modelop" value="<?php echo $fila ['Modelo']; ?>"> 
                      <input type="hidden" name="marcap" value="<?php echo $fila ['Marca']; ?>"> 
                      <input type="hidden" name="imagenp" value="<?php echo $fila ['Imagen']; ?>">
                      <input class="btn btn-success" type="submit" value="Seleccionar"  name = "accion"> 
                      <button class="btn btn-danger" type="submit" name="accion" value="btneliminar">Eliminar</button>
                      <button class="btn btn-primary" type="submit" name="accion" value="btncancelar">Cancelar</button>
                    </form>
                  </td>
                </tr>
                <?php }?><!--Cerrando Bucle Foreach-->
              </tbody></table>
            </div>
            <!-- /.box-body -->
          </div>
          <!--Mostrar Productos Fin-->
          <!-- /.box -->
        </div>

<?php include("footer.php");?>