<?php
define("SERVIDOR", "localhost");
define("USUARIO", "root");
define("PASSWORD", "");
define("BD", "store");

//CONSTANTES PARA CONTROLAR LA PRODUCCTION
define("LINKAPI", "https://api.sandbox.paypal.com");
define("CLIENTID", "Afm6GIAmClum0sahs4eRYfy1CK-Zh7m4oVTOIUw9qwTpkGznC6hwxIpS3eCV74-6icpnKN1AX4vYdzWa");
define("SECRET", "EF4ejD-TryWD5DpezAtd6_7JOzSFgl5OiYtWITYG1hF5tY87oEWT_mMgnnKd9OTxw53nAs1d-_E719_i");

?>