<?php
session_start();
if(!isset($_SESSION['administrador'])){
	header('location:index.php');

}else{
	//print_r($_SESSION['administrador']);
	$nombreAdmin = $_SESSION['administrador']['Nombres'];
}
?>